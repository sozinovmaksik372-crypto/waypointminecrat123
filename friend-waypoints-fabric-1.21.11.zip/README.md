# Friend Waypoints — Fabric 1.21.11

Client-side Fabric mod. It does not require a server-side mod.

## What it does

- Open the configuration from Mod Menu.
- Add/remove exact Minecraft usernames as friends.
- Choose the key used to place a waypoint.
- Press the key to send `/msg <friend> <x> <y> <z>%%` to every configured friend.
- The `%%` suffix is the protocol marker.
- Incoming encoded messages are hidden from chat and create a waypoint.
- The waypoint is a tall colored beam.
- Lifetime and color are configurable.
- No `/sendcorder` command is included.

## Important limitation

This uses ordinary `/msg` chat because the mod is intended to work without a server-side mod. Therefore the server must support `/msg` (or an equivalent command). The mod can hide the encoded message on the client, but it cannot prevent a server/plugin from logging it.

The beam is client-rendered and has no server-side waypoint entity. Vanilla's render/frustum limits still apply at extreme distances; the mod itself does not impose a distance value.

## Build

Use Java 21 and a modern Gradle installation, then:

```text
gradle build
```

The jar will be in `build/libs/`.

Install Fabric API and Mod Menu 17.0.0 (or another compatible 1.21.11 Mod Menu release) in the client.
