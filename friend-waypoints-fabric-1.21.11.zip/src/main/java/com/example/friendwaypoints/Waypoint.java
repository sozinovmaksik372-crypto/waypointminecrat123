package com.example.friendwaypoints;

public record Waypoint(String sender, double x, double y, double z, long expiresAt) {
    public boolean expired(long now) {
        return expiresAt > 0 && now >= expiresAt;
    }
}
