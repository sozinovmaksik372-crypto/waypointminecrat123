package com.example.friendwaypoints;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class FriendWaypointsClient implements ClientModInitializer {
    public static final String MOD_ID = "friendwaypoints";
    public static Config CONFIG;
    public static KeyBinding MARK_KEY;

    private static final List<Waypoint> WAYPOINTS = new ArrayList<>();

    // Protocol: "... x y z%%"
    private static final Pattern COORDS = Pattern.compile(
            "(-?\d+(?:\.\d+)?)\\s+(-?\d+(?:\.\d+)?)\\s+(-?\d+(?:\.\d+)?)%%\\s*$"
    );

    @Override
    public void onInitializeClient() {
        CONFIG = Config.load();

        MARK_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.friendwaypoints.mark",
                InputUtil.Type.KEYSYM,
                CONFIG.keyCode,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (MARK_KEY.wasPressed()) {
                placeAndSendWaypoint(client);
            }

            long now = System.currentTimeMillis();
            WAYPOINTS.removeIf(w -> w.expired(now));
        });

        // Chat messages have a sender GameProfile, so this path can identify the friend reliably.
        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signedMessage, sender, params, timestamp) -> {
            String plain = message.getString();
            Parsed parsed = parse(plain);
            if (parsed != null && isFriend(sender.getName())) {
                addWaypoint(parsed.sender(), parsed.x(), parsed.y(), parsed.z());
                return false;
            }
            return true;
        });

        // /msg is normally delivered as a server/system (game) message.
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            String plain = message.getString();
            Parsed parsed = parse(plain);
            if (parsed != null) {
                String friend = findFriendNameInMessage(plain);
                if (friend != null) {
                    addWaypoint(friend, parsed.x(), parsed.y(), parsed.z());
                    return false;
                }
                // Hide our own encoded /msg confirmation too.
                if (plain.contains("%%")) {
                    return false;
                }
            }
            return true;
        });

        WorldRenderEvents.END_MAIN.register(FriendWaypointsClient::renderWaypoints);
    }

    private static void placeAndSendWaypoint(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (CONFIG.friends.isEmpty()) {
            client.player.sendMessage(Text.translatable("screen.friendwaypoints.hint"), true);
            return;
        }

        double x = client.player.getX();
        double y = client.player.getY();
        double z = client.player.getZ();

        String coords = format(x) + " " + format(y) + " " + format(z) + "%%";
        for (String friend : new ArrayList<>(CONFIG.friends)) {
            if (!friend.isBlank()) {
                client.player.sendCommand("msg " + friend + " " + coords);
            }
        }

        // Show it locally without exposing the encoded protocol in chat.
        addWaypoint(client.player.getName().getString(), x, y, z);
    }

    private static String format(double value) {
        return String.format(java.util.Locale.ROOT, "%.2f", value);
    }

    private static Parsed parse(String text) {
        if (!text.contains("%%")) return null;
        Matcher matcher = COORDS.matcher(text);
        if (!matcher.find()) return null;
        try {
            double x = Double.parseDouble(matcher.group(1));
            double y = Double.parseDouble(matcher.group(2));
            double z = Double.parseDouble(matcher.group(3));
            String sender = text.substring(0, matcher.start()).trim();
            return new Parsed(sender, x, y, z);
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    private static boolean isFriend(String name) {
        if (name == null) return false;
        return CONFIG.friends.stream().anyMatch(f -> f.equalsIgnoreCase(name));
    }

    private static String findFriendNameInMessage(String message) {
        for (String friend : CONFIG.friends) {
            if (message.matches("(?s).*\\b" + Pattern.quote(friend) + "\\b.*")) {
                return friend;
            }
        }
        return null;
    }

    private static void addWaypoint(String sender, double x, double y, double z) {
        long expires = CONFIG.lifetimeSeconds <= 0
                ? 0
                : System.currentTimeMillis() + CONFIG.lifetimeSeconds * 1000L;

        synchronized (WAYPOINTS) {
            WAYPOINTS.add(new Waypoint(sender, x, y, z, expires));
        }
    }

    private static void renderWaypoints(net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        synchronized (WAYPOINTS) {
            long now = System.currentTimeMillis();
            WAYPOINTS.removeIf(w -> w.expired(now));

            if (WAYPOINTS.isEmpty()) return;

            MatrixStack matrices = context.matrices();
            VertexConsumerProvider consumers = context.consumers();
            VertexConsumer vertexConsumer = consumers.getBuffer(RenderLayer.getLines());

            var camera = context.camera();
            double camX = camera.getPos().x;
            double camY = camera.getPos().y;
            double camZ = camera.getPos().z;

            int color = CONFIG.color & 0xFFFFFF;
            int red = (color >> 16) & 0xFF;
            int green = (color >> 8) & 0xFF;
            int blue = color & 0xFF;

            matrices.push();
            var matrix = matrices.peek().getPositionMatrix();

            for (Waypoint w : WAYPOINTS) {
                double rx = w.x() - camX;
                double ry = w.y() - camY;
                double rz = w.z() - camZ;

                // Tall beacon-like beam. RenderLayer.getLines is used so the line is cheap.
                vertexConsumer.vertex(matrix, (float) rx, (float) ry, (float) rz)
                        .color(red, green, blue, 255)
                        .lineWidth(3.0f);
                vertexConsumer.vertex(matrix, (float) rx, (float) (ry + 256.0), (float) rz)
                        .color(red, green, blue, 255)
                        .lineWidth(3.0f);
            }

            matrices.pop();
        }
    }

    private record Parsed(String sender, double x, double y, double z) {}
}
