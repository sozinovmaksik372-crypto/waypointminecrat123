package com.example.friendwaypoints;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;

public final class FriendWaypointsScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget friendField;
    private TextFieldWidget lifetimeField;
    private TextFieldWidget colorField;
    private int selectedFriend = -1;
    private boolean waitingForKey = false;

    public FriendWaypointsScreen(Screen parent) {
        super(Text.translatable("screen.friendwaypoints.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 150;
        int top = Math.max(20, this.height / 2 - 145);

        friendField = addDrawableChild(new TextFieldWidget(
                this.textRenderer, left, top + 35, 200, 20,
                Text.translatable("screen.friendwaypoints.friends")
        ));
        friendField.setMaxLength(16);

        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.friendwaypoints.add"), button -> {
            String name = friendField.getText().trim();
            if (!name.isEmpty() && !FriendWaypointsClient.CONFIG.friends.stream()
                    .anyMatch(f -> f.equalsIgnoreCase(name))) {
                FriendWaypointsClient.CONFIG.friends.add(name);
                friendField.setText("");
            }
        }).dimensions(left + 208, top + 35, 92, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.friendwaypoints.remove"), button -> {
            if (selectedFriend >= 0 && selectedFriend < FriendWaypointsClient.CONFIG.friends.size()) {
                FriendWaypointsClient.CONFIG.friends.remove(selectedFriend);
                selectedFriend = -1;
            }
        }).dimensions(left, top + 128, 300, 20).build());

        addDrawableChild(ButtonWidget.builder(getBindText(), button -> {
            waitingForKey = true;
            button.setMessage(Text.translatable("screen.friendwaypoints.waiting"));
        }).dimensions(left, top + 155, 300, 20).build());

        lifetimeField = addDrawableChild(new TextFieldWidget(
                this.textRenderer, left, top + 205, 140, 20,
                Text.translatable("screen.friendwaypoints.duration")
        ));
        lifetimeField.setText(Integer.toString(FriendWaypointsClient.CONFIG.lifetimeSeconds));
        lifetimeField.setMaxLength(6);

        colorField = addDrawableChild(new TextFieldWidget(
                this.textRenderer, left + 160, top + 205, 140, 20,
                Text.translatable("screen.friendwaypoints.color")
        ));
        colorField.setText(String.format("#%06X", FriendWaypointsClient.CONFIG.color & 0xFFFFFF));
        colorField.setMaxLength(7);

        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.friendwaypoints.save"), button -> saveAndClose())
                .dimensions(left, top + 245, 145, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.friendwaypoints.cancel"), button -> close())
                .dimensions(left + 155, top + 245, 145, 20).build());
    }

    private Text getBindText() {
        String key = InputUtil.fromKeyCode(FriendWaypointsClient.CONFIG.keyCode, 0).getLocalizedText().getString();
        return Text.translatable("screen.friendwaypoints.bind").append(": " + key);
    }

    private void saveAndClose() {
        try {
            int lifetime = Integer.parseInt(lifetimeField.getText().trim());
            if (lifetime < 1 || lifetime > 86400) throw new NumberFormatException();
            String hex = colorField.getText().trim();
            if (hex.startsWith("#")) hex = hex.substring(1);
            if (hex.length() != 6) throw new NumberFormatException();
            int color = Integer.parseInt(hex, 16);

            FriendWaypointsClient.CONFIG.lifetimeSeconds = lifetime;
            FriendWaypointsClient.CONFIG.color = color;
            FriendWaypointsClient.CONFIG.keyCode = FriendWaypointsClient.MARK_KEY.getBoundKey().getCode();
            FriendWaypointsClient.CONFIG.save();
            close();
        } catch (NumberFormatException e) {
            this.colorField.setText("#FF0000");
            this.lifetimeField.setText("60");
        }
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyInput input) {
        if (waitingForKey) {
            int keyCode = input.key();
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                FriendWaypointsClient.MARK_KEY.setBoundKey(InputUtil.Type.KEYSYM.createFromCode(keyCode));
                FriendWaypointsClient.CONFIG.keyCode = keyCode;
                waitingForKey = false;
                clearAndInit();
                return true;
            }
            waitingForKey = false;
            clearAndInit();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        renderBackground(context, mouseX, mouseY, deltaTicks);

        int left = this.width / 2 - 150;
        int top = Math.max(20, this.height / 2 - 145);

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, top, 0xFFFFFF);
        context.drawTextWithShadow(this.textRenderer,
                Text.translatable("screen.friendwaypoints.hint"), left, top + 8, 0xAAAAAA);

        int y = top + 65;
        int i = 0;
        for (String friend : new ArrayList<>(FriendWaypointsClient.CONFIG.friends)) {
            int color = (i == selectedFriend) ? 0x55AAFF : 0xFFFFFF;
            context.drawTextWithShadow(this.textRenderer, Text.literal(friend), left + 8, y, color);
            y += 18;
            i++;
            if (i >= 5) break;
        }

        context.drawTextWithShadow(this.textRenderer,
                Text.translatable("screen.friendwaypoints.duration"), left, top + 190, 0xFFFFFF);
        context.drawTextWithShadow(this.textRenderer,
                Text.translatable("screen.friendwaypoints.color"), left + 160, top + 190, 0xFFFFFF);

        super.render(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent click, boolean doubled) {
        int left = this.width / 2 - 150;
        int top = Math.max(20, this.height / 2 - 145);
        int x = click.x();
        int y = click.y();

        if (x >= left && x <= left + 300 && y >= top + 62 && y < top + 62 + 5 * 18) {
            int index = (y - (top + 62)) / 18;
            if (index < FriendWaypointsClient.CONFIG.friends.size()) {
                selectedFriend = index;
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }
}
