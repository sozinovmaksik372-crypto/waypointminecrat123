package com.example.friendwaypoints;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("friendwaypoints.json");

    public List<String> friends = new ArrayList<>();
    public int keyCode = org.lwjgl.glfw.GLFW.GLFW_KEY_H;
    public int lifetimeSeconds = 60;
    public int color = 0x55AAFF;

    public static Config load() {
        try {
            if (Files.exists(FILE)) {
                try (Reader reader = Files.newBufferedReader(FILE)) {
                    Config cfg = GSON.fromJson(reader, Config.class);
                    if (cfg != null) {
                        cfg.normalize();
                        return cfg;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        Config cfg = new Config();
        cfg.normalize();
        cfg.save();
        return cfg;
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                GSON.toJson(this, writer);
            }
        } catch (Exception ignored) {
        }
    }

    private void normalize() {
        if (friends == null) friends = new ArrayList<>();
        friends.removeIf(s -> s == null || s.isBlank());
        lifetimeSeconds = Math.max(1, Math.min(86400, lifetimeSeconds));
        color &= 0xFFFFFF;
    }
}
